// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__STRUCT_H_
#define UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/FilteredSensor in the package ucb_interfaces.
typedef struct ucb_interfaces__msg__FilteredSensor
{
  double sensor_value;
  rosidl_runtime_c__String name;
} ucb_interfaces__msg__FilteredSensor;

// Struct for a sequence of ucb_interfaces__msg__FilteredSensor.
typedef struct ucb_interfaces__msg__FilteredSensor__Sequence
{
  ucb_interfaces__msg__FilteredSensor * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ucb_interfaces__msg__FilteredSensor__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__STRUCT_H_
