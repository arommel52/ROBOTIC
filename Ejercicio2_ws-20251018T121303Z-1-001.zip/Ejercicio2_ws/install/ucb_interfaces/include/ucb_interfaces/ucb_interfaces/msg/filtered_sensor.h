// generated from rosidl_generator_c/resource/idl.h.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACES__MSG__FILTERED_SENSOR_H_
#define UCB_INTERFACES__MSG__FILTERED_SENSOR_H_

#include "ucb_interfaces/msg/detail/filtered_sensor__struct.h"
#include "ucb_interfaces/msg/detail/filtered_sensor__functions.h"
#include "ucb_interfaces/msg/detail/filtered_sensor__type_support.h"

#endif  // UCB_INTERFACES__MSG__FILTERED_SENSOR_H_
