// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__TYPE_SUPPORT_HPP_
#define UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "ucb_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_ucb_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  ucb_interfaces,
  msg,
  FilteredSensor
)();
#ifdef __cplusplus
}
#endif

#endif  // UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__TYPE_SUPPORT_HPP_
