// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice
#ifndef UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "ucb_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ucb_interfaces
size_t get_serialized_size_ucb_interfaces__msg__FilteredSensor(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ucb_interfaces
size_t max_serialized_size_ucb_interfaces__msg__FilteredSensor(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ucb_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, ucb_interfaces, msg, FilteredSensor)();

#ifdef __cplusplus
}
#endif

#endif  // UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
