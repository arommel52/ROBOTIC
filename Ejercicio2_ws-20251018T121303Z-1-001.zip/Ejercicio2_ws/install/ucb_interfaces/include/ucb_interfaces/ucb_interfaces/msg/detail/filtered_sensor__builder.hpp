// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__BUILDER_HPP_
#define UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ucb_interfaces/msg/detail/filtered_sensor__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ucb_interfaces
{

namespace msg
{

namespace builder
{

class Init_FilteredSensor_name
{
public:
  explicit Init_FilteredSensor_name(::ucb_interfaces::msg::FilteredSensor & msg)
  : msg_(msg)
  {}
  ::ucb_interfaces::msg::FilteredSensor name(::ucb_interfaces::msg::FilteredSensor::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ucb_interfaces::msg::FilteredSensor msg_;
};

class Init_FilteredSensor_sensor_value
{
public:
  Init_FilteredSensor_sensor_value()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FilteredSensor_name sensor_value(::ucb_interfaces::msg::FilteredSensor::_sensor_value_type arg)
  {
    msg_.sensor_value = std::move(arg);
    return Init_FilteredSensor_name(msg_);
  }

private:
  ::ucb_interfaces::msg::FilteredSensor msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ucb_interfaces::msg::FilteredSensor>()
{
  return ucb_interfaces::msg::builder::Init_FilteredSensor_sensor_value();
}

}  // namespace ucb_interfaces

#endif  // UCB_INTERFACES__MSG__DETAIL__FILTERED_SENSOR__BUILDER_HPP_
