// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ucb_interfaces:msg/FilteredSensor.idl
// generated code does not contain a copyright notice
#include "ucb_interfaces/msg/detail/filtered_sensor__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `name`
#include "rosidl_runtime_c/string_functions.h"

bool
ucb_interfaces__msg__FilteredSensor__init(ucb_interfaces__msg__FilteredSensor * msg)
{
  if (!msg) {
    return false;
  }
  // sensor_value
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    ucb_interfaces__msg__FilteredSensor__fini(msg);
    return false;
  }
  return true;
}

void
ucb_interfaces__msg__FilteredSensor__fini(ucb_interfaces__msg__FilteredSensor * msg)
{
  if (!msg) {
    return;
  }
  // sensor_value
  // name
  rosidl_runtime_c__String__fini(&msg->name);
}

bool
ucb_interfaces__msg__FilteredSensor__are_equal(const ucb_interfaces__msg__FilteredSensor * lhs, const ucb_interfaces__msg__FilteredSensor * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // sensor_value
  if (lhs->sensor_value != rhs->sensor_value) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  return true;
}

bool
ucb_interfaces__msg__FilteredSensor__copy(
  const ucb_interfaces__msg__FilteredSensor * input,
  ucb_interfaces__msg__FilteredSensor * output)
{
  if (!input || !output) {
    return false;
  }
  // sensor_value
  output->sensor_value = input->sensor_value;
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  return true;
}

ucb_interfaces__msg__FilteredSensor *
ucb_interfaces__msg__FilteredSensor__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ucb_interfaces__msg__FilteredSensor * msg = (ucb_interfaces__msg__FilteredSensor *)allocator.allocate(sizeof(ucb_interfaces__msg__FilteredSensor), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ucb_interfaces__msg__FilteredSensor));
  bool success = ucb_interfaces__msg__FilteredSensor__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ucb_interfaces__msg__FilteredSensor__destroy(ucb_interfaces__msg__FilteredSensor * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ucb_interfaces__msg__FilteredSensor__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ucb_interfaces__msg__FilteredSensor__Sequence__init(ucb_interfaces__msg__FilteredSensor__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ucb_interfaces__msg__FilteredSensor * data = NULL;

  if (size) {
    data = (ucb_interfaces__msg__FilteredSensor *)allocator.zero_allocate(size, sizeof(ucb_interfaces__msg__FilteredSensor), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ucb_interfaces__msg__FilteredSensor__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ucb_interfaces__msg__FilteredSensor__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ucb_interfaces__msg__FilteredSensor__Sequence__fini(ucb_interfaces__msg__FilteredSensor__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ucb_interfaces__msg__FilteredSensor__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ucb_interfaces__msg__FilteredSensor__Sequence *
ucb_interfaces__msg__FilteredSensor__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ucb_interfaces__msg__FilteredSensor__Sequence * array = (ucb_interfaces__msg__FilteredSensor__Sequence *)allocator.allocate(sizeof(ucb_interfaces__msg__FilteredSensor__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ucb_interfaces__msg__FilteredSensor__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ucb_interfaces__msg__FilteredSensor__Sequence__destroy(ucb_interfaces__msg__FilteredSensor__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ucb_interfaces__msg__FilteredSensor__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ucb_interfaces__msg__FilteredSensor__Sequence__are_equal(const ucb_interfaces__msg__FilteredSensor__Sequence * lhs, const ucb_interfaces__msg__FilteredSensor__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ucb_interfaces__msg__FilteredSensor__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ucb_interfaces__msg__FilteredSensor__Sequence__copy(
  const ucb_interfaces__msg__FilteredSensor__Sequence * input,
  ucb_interfaces__msg__FilteredSensor__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ucb_interfaces__msg__FilteredSensor);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ucb_interfaces__msg__FilteredSensor * data =
      (ucb_interfaces__msg__FilteredSensor *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ucb_interfaces__msg__FilteredSensor__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ucb_interfaces__msg__FilteredSensor__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ucb_interfaces__msg__FilteredSensor__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
