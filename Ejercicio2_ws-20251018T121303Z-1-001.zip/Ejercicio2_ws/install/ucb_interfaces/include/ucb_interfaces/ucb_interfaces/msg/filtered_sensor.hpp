// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACES__MSG__FILTERED_SENSOR_HPP_
#define UCB_INTERFACES__MSG__FILTERED_SENSOR_HPP_

#include "ucb_interfaces/msg/detail/filtered_sensor__struct.hpp"
#include "ucb_interfaces/msg/detail/filtered_sensor__builder.hpp"
#include "ucb_interfaces/msg/detail/filtered_sensor__traits.hpp"
#include "ucb_interfaces/msg/detail/filtered_sensor__type_support.hpp"

#endif  // UCB_INTERFACES__MSG__FILTERED_SENSOR_HPP_
